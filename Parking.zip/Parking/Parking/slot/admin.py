from django.contrib import admin
from . models import Parking

# Register your models here.
admin.site.register(Parking)
