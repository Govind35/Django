from django.apps import AppConfig


class SlotConfig(AppConfig):
    name = 'slot'
